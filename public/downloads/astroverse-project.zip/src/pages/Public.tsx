import { useEffect, useRef, useState } from 'react';

import { Link } from 'react-router-dom';

import {

  ArrowDown,

  ArrowUpRight,

  CalendarDays,

  MapPin,

  Rocket,

  Globe2,

  Code2,

  Users,

  Sparkles,

  Orbit,

  Lightbulb,

  Mic2,

  Network,

  GraduationCap,

  Trophy,

  Plus,

  Minus,

} from 'lucide-react';

import {

  ArrowLink,

  Eyebrow,

  OptimizedImage,

  SectionTitle,

} from '../components/UI';

import Gallery from '../components/Gallery';

import {

  event,

  faqs,

  schedule,

  videos,

} from '../data';

import { api } from '../lib/api';

function Countdown() {

  const [remaining, setRemaining] = useState(

    Math.max(

      0,

      new Date(event.startsAt).getTime() - Date.now()

    )

  );

  useEffect(() => {

    const timer = setInterval(() => {

      setRemaining(

        Math.max(

          0,

          new Date(event.startsAt).getTime() - Date.now()

        )

      );

    }, 1000);

    return () => clearInterval(timer);

  }, []);

  const values = [

    Math.floor(remaining / 86400000),

    Math.floor(remaining / 3600000) % 24,

    Math.floor(remaining / 60000) % 60,

    Math.floor(remaining / 1000) % 60,

  ];

  return (

    <div className="countdown">

      <div className="countdown-label">

        <span className="live-dot" />

        {remaining

          ? 'COUNTDOWN TO LIFTOFF'

          : 'THE MISSION IS HERE'}

      </div>

      <div className="countdown-numbers">

        {values.map((value, index) => (

          <div key={index}>

            <strong>

              {String(value).padStart(2, '0')}

            </strong>

            <span>

              {[

                'DAYS',

                'HOURS',

                'MINUTES',

                'SECONDS',

              ][index]}

            </span>

            {index < 3 && <b>:</b>}

          </div>

        ))}

      </div>

    </div>

  );

}

function Hero() {

  const heroRef = useRef<HTMLElement>(null);

  const [registrationOpen, setRegistrationOpen] =

    useState<boolean | null>(null);

  useEffect(() => {

    let active = true;

    api('/event')

      .then((data) => {

        if (active) {

          setRegistrationOpen(

            data.event?.registrationOpen ?? null

          );

        }

      })

      .catch(() => {});

    return () => {

      active = false;

    };

  }, []);

  const move = (

    event: React.MouseEvent<HTMLElement>

  ) => {

    if (

      window.matchMedia(

        '(prefers-reduced-motion: reduce)'

      ).matches

    ) {

      return;

    }

    const rect =

      event.currentTarget.getBoundingClientRect();

    heroRef.current?.style.setProperty(

      '--px',

      `${(

        (event.clientX -

          rect.left -

          rect.width / 2) *

        0.009

      ).toFixed(2)}px`

    );

    heroRef.current?.style.setProperty(

      '--py',

      `${(

        (event.clientY -

          rect.top -

          rect.height / 2) *

        0.009

      ).toFixed(2)}px`

    );

  };

  return (

    <section

      className="hero"

      ref={heroRef}

      onMouseMove={move}

      onMouseLeave={() => {

        heroRef.current?.style.setProperty(

          '--px',

          '0px'

        );

        heroRef.current?.style.setProperty(

          '--py',

          '0px'

        );

      }}

    >

      {/* =====================================================

          HERO BACKGROUND

          The actual cinematic video is handled by Layout.tsx.

          This keeps the existing hero artwork and particles.

          Decorative orbit paths and planets have been removed.

          ===================================================== */}

      <div

        className="hero-art"

        aria-hidden="true"

      >

        <img

          className="hero-space"

          src="/img/space-hero.jpeg"

          alt=""

          fetchPriority="high"

        />

        <div className="hero-vignette" />

        {/* Decorative planets/orbits removed */}

      </div>

      {/* =====================================================

          HERO CONTENT

          ===================================================== */}

      <div className="hero-content container">

        <div className="mission-pill">

          <span className="live-dot" />

          MISSION 2026

          <span className="pill-divider" />

          {registrationOpen === null

            ? 'JOIN THE MISSION'

            : registrationOpen

              ? 'REGISTRATION OPEN'

              : 'REGISTRATION CLOSED'}

        </div>

        <p className="hero-kicker">

          NASA INTERNATIONAL SPACE APPS CHALLENGE

        </p>

        {/* =================================================

            UPDATED HERO HEADING

            ================================================= */}

        <h1>

          NASA SPACE

          <br />

          APPS

          <br />

          <span>

            CHALLENGE 2026

          </span>

        </h1>

        <p className="hero-description">
          QUESTION THE UNKNOWN. CREATE WHAT’S NEXT.
          <br className="desktop-break" />
          DISCOVER · INNOVATE · MAKE AN IMPACT.
        </p>

        <div className="hero-buttons">

          <ArrowLink

            primary

            to="/register"

          >

            Register now

          </ArrowLink>

          <ArrowLink to="/#about">

            Explore ASTROVERSE

          </ArrowLink>

        </div>

        <div className="hero-details">

          <span>

            <CalendarDays size={16} />

            14–16 November 2026

          </span>

          <span>

            <MapPin size={16} />

            BIAS, Bhimtal

          </span>

        </div>

      </div>

      {/* =====================================================

          HERO NOTE

          ===================================================== */}

      <div className="hero-note">

        <span className="note-line" />

        <span>

          DON’T JUST LOOK AT THE STARS.

          <br />

          <strong>

            BUILD SOMETHING THAT REACHES THEM.

          </strong>

        </span>

      </div>

      {/* =====================================================

          SCROLL CUE

          ===================================================== */}

      <a

        className="scroll-cue"

        href="#about"

      >

        <ArrowDown size={16} />

        <span>

          SCROLL TO DISCOVER

        </span>

      </a>

    </section>

  );

}

export function Home() {

  return (

    <>

      <Hero />

      <div className="mission-strip container">

        <Countdown />

        <a
          className="mission-host"
          href="https://birlainstitute.co.in/"
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Visit Birla Institute of Applied Sciences official website"
        >
          <div className="mission-host-mark" aria-hidden="true">
            <img
              src="/img/my-logo.png.png"
              alt=""
              width={54}
              height={54}
            />
          </div>

          <div>
            <span className="mono muted">OUR LAUNCHPAD</span>
            <strong>Birla Institute of Applied Sciences</strong>
            <span>Bhimtal, Uttarakhand</span>
          </div>

          <ArrowUpRight size={22} />
        </a>
      </div>

      <div className="mission-facts container">

        {[

          [Rocket, '03', 'DAYS OF DISCOVERY'],

          [Users, '4–6', 'MINDS. ONE TEAM.'],

          [

            Globe2,

            'NASA',

            'OPEN DATA. REAL CHALLENGES.',

          ],

          [

            Orbit,

            '∞',

            'POSSIBILITIES TO EXPLORE',

          ],

        ].map(

          ([Icon, value, label], index) => {

            const FactIcon =

              Icon as typeof Rocket;

            return (

              <div key={index}>

                <FactIcon size={23} />

                <strong>

                  {String(value)}

                </strong>

                <span>

                  {String(label)}

                </span>

              </div>

            );

          }

        )}

      </div>

      <AboutSection />

      <HighlightsSection />

      <Gallery preview />

      <QuizPreview />

      <ScheduleSection preview />

      <FAQSection preview />

    </>

  );

}

export function AboutSection() {

  return (

    <section

      id="about"

      className="about-section section container"

    >

      <div className="about-images">

        <div className="photo-frame">

          <OptimizedImage

            src="/gallery/event-03.jpeg"

            alt="Space Apps participants celebrating their projects"

          />

        </div>

        <div className="photo-inset">

          <OptimizedImage

            src="/gallery/event-11.jpeg"

            alt="Participants collaborating on real projects"

          />

        </div>

        <div className="image-stamp">

          <Orbit size={30} />

          <span>

            CURIOUS MINDS.

            <br />

            EXTRAORDINARY IDEAS.

          </span>

        </div>

        <span className="image-crosshair">

          +

        </span>

      </div>

      <div className="about-copy">

        <Eyebrow>

          WELCOME TO ASTROVERSE

        </Eyebrow>

        <h2>

          DOWN TO EARTH.

          <br />

          <span className="serif-accent">

            Looking beyond.

          </span>

        </h2>

        <p>

          Some of the biggest discoveries begin

          with a simple question. At ASTROVERSE,

          we give that curiosity a place to take off.

        </p>

        <p>

          Join the NASA International Space Apps

          Challenge 2026 at Birla Institute of

          Applied Sciences, Bhimtal. Work with open

          data, connect with different minds, and

          turn a real-world challenge into something

          remarkable.

        </p>

        <div className="about-values">

          <span>

            <Sparkles size={15} />

            No idea too ambitious

          </span>

          <span>

            <Users size={15} />

            Every perspective matters

          </span>

        </div>

        <ArrowLink to="/space-apps">

          Meet the mission

        </ArrowLink>

      </div>

    </section>

  );

}

const highlights = [

  {

    icon: Code2,

    title: 'HACK THE POSSIBLE',

    subtitle: 'The hackathon',

    text: 'Turn NASA open data into solutions for challenges on Earth and beyond.',

    tag: '01 / BUILD',

  },

  {

    icon: Orbit,

    title: 'FOLLOW YOUR CURIOSITY',

    subtitle: 'Space science & technology',

    text: 'Connect the dots between our planet, space science, and emerging technology.',

    tag: '02 / EXPLORE',

  },

  {

    icon: GraduationCap,

    title: 'LEARN FROM EACH OTHER',

    subtitle: 'Mentorship & workshops',

    text: 'Ask better questions, pick up new skills, and find a fresh perspective with mentors.',

    tag: '03 / LEARN',

  },

  {

    icon: Users,

    title: 'FIND YOUR PEOPLE',

    subtitle: 'Teamwork & networking',

    text: 'Build alongside a community that shares your curiosity. Create connections that last.',

    tag: '04 / CONNECT',

  },

];

export function HighlightsSection() {

  return (

    <section

      className="highlights-section section container"

      id="experience"

    >

      <SectionTitle

        label="MORE THAN A HACKATHON"

        title="Two days. A whole new perspective."

      >

        <ArrowLink to="/why-participate">

          Why participate?

        </ArrowLink>

      </SectionTitle>

      <div className="highlight-grid">

        {highlights.map((item) => (

          <article

            className="highlight-card"

            key={item.title}

          >

            <div className="highlight-top">

              <item.icon

                size={29}

                strokeWidth={1.5}

              />

              <span>

                {item.tag}

              </span>

            </div>

            <span className="highlight-subtitle">

              {item.subtitle}

            </span>

            <h3>

              {item.title}

            </h3>

            <p>

              {item.text}

            </p>

            <Link

              to="/register"

              aria-label={`Register to ${item.subtitle.toLowerCase()}`}

            >

              <ArrowUpRight size={20} />

            </Link>

          </article>

        ))}

      </div>

      <div className="experience-tags">

        {[

          'Innovation',

          'NASA challenges',

          'Problem solving',

          'Presentations',

          'Creativity',

          'Real-world impact',

        ].map((item) => (

          <span key={item}>

            <Plus size={11} />

            {item}

          </span>

        ))}

      </div>

    </section>

  );

}

function QuizPreview() {

  return (

    <section className="quiz-promo container">

      <div

        className="quiz-orbit"

        aria-hidden="true"

      >

        <Orbit

          size={145}

          strokeWidth={0.7}

        />

        <span className="tiny-star">

          +

        </span>

      </div>

      <div>

        <Eyebrow>

          A LITTLE CURIOSITY CHECK

        </Eyebrow>

        <h2>

          Think you know your universe?

        </h2>

        <p>

          From the Red Planet to rocket science.

          Take a quick space quiz.

        </p>

      </div>

      <ArrowLink to="/quiz">

        Test your knowledge

      </ArrowLink>

    </section>

  );

}

export function ScheduleSection({

  preview = false,

}: {

  preview?: boolean;

}) {

  return (

    <section className="schedule-section section container">

      <SectionTitle

        label="YOUR FLIGHT PLAN"

        title="From “what if” to what’s next."

      >

        {preview && (

          <ArrowLink to="/schedule">

            Full event schedule

          </ArrowLink>

        )}

      </SectionTitle>

      <div className="schedule-grid">

        {schedule.map((day) => (

          <article

            className="day-card"

            key={day.day}

          >

            <header>

              <div className="day-date">

                <strong>

                  {day.day}

                </strong>

                <span>

                  {day.month}

                  <br />

                  2026

                </span>

              </div>

              <span className="mono muted">

                DAY {day.day === '14' ? '01' : '02'}

              </span>

            </header>

            <h3>

              {day.title}

            </h3>

            <div className="timeline">

              {day.stages.map(

                (stage, index) => (

                  <div

                    className="timeline-item"

                    key={stage.title}

                  >

                    <span className="timeline-dot" />

                    <span className="mono timeline-label">

                      {stage.label}

                    </span>

                    <h4>

                      {stage.title}

                    </h4>

                    {!preview && (

                      <p>

                        {stage.text}

                      </p>

                    )}

                    <span className="timeline-number">

                      0{index + 1}

                    </span>

                  </div>

                )

              )}

            </div>

          </article>

        ))}

      </div>

      <p className="schedule-note">

        <CalendarDays size={14} />

        Sequence shown for planning. Final session

        times will be confirmed by the organizers.

      </p>

    </section>

  );

}

export function FAQSection({

  preview = false,

}: {

  preview?: boolean;

}) {

  const [open, setOpen] =

    useState<number | null>(0);

  return (

    <section className="faq-section section container">

      <div className="faq-heading">

        <Eyebrow>

          BEFORE YOU BLAST OFF

        </Eyebrow>

        <h2>

          GOT QUESTIONS?

          <br />

          <span className="serif-accent">

            We’ve got you.

          </span>

        </h2>

        <p>

          Your mission briefing, minus the jargon.

        </p>

        {preview && (

          <ArrowLink to="/faq">

            All FAQs

          </ArrowLink>

        )}

        <Link

          className="text-link"

          to="/contact"

        >

          Venue & contact

          <ArrowUpRight size={15} />

        </Link>

      </div>

      <div className="faq-list">

        {(preview

          ? faqs.slice(0, 5)

          : faqs

        ).map(

          ([question, answer], index) => (

            <div

              className={`faq-item ${

                open === index

                  ? 'expanded'

                  : ''

              }`}

              key={question}

            >

              <button

                aria-expanded={

                  open === index

                }

                aria-controls={`faq-answer-${index}`}

                onClick={() =>

                  setOpen(

                    open === index

                      ? null

                      : index

                  )

                }

              >

                <span className="faq-number">

                  {String(index + 1).padStart(

                    2,

                    '0'

                  )}

                </span>

                <span>

                  {question}

                </span>

                {open === index ? (

                  <Minus size={18} />

                ) : (

                  <Plus size={18} />

                )}

              </button>

              <div

                id={`faq-answer-${index}`}

                hidden={open !== index}

              >

                <p>

                  {answer}

                </p>

              </div>

            </div>

          )

        )}

      </div>

    </section>

  );

}

export function PublicPage({

  type,

}: {

  type: string;

}) {

  if (type === 'schedule') {

    return (

      <div className="page">

        <PageIntro

          label="14–15 NOVEMBER 2026"

          title="THE MISSION PLAN."

          text="Two days to explore, build, and bring your ideas to life. Here’s how the journey unfolds."

        />

        <ScheduleSection />

      </div>

    );

  }

  if (type === 'faq') {

    return (

      <div className="page">

        <PageIntro

          label="YOUR PRE-LAUNCH BRIEFING"

          title="BEFORE THE COUNTDOWN."

          text="The practical details, from assembling your team to verifying your registration."

        />

        <FAQSection />

      </div>

    );

  }

  if (type === 'highlights') {

    return (

      <div className="page">

        <PageIntro

          label="THE ASTROVERSE EXPERIENCE"

          title="A LITTLE SPACE. A LOT OF POSSIBILITY."

          text="Hackathons, workshops, open data, and a room full of people who see the world differently."

        />

        <HighlightsSection />

        <Gallery preview />

      </div>

    );

  }

  if (type === 'about') {

    return (

      <div className="page">

        <PageIntro

          label="THIS IS ASTROVERSE"

          title="WHERE CURIOUS MINDS FIND THEIR ORBIT."

          text="An event built around one belief: extraordinary things happen when different perspectives work together."

        />

        <AboutSection />

        <HighlightsSection />

      </div>

    );

  }

  if (type === 'space-apps') {

    return (

      <div className="page">

        <PageIntro

          label="NASA INTERNATIONAL SPACE APPS CHALLENGE 2026"

          title="OPEN DATA. OPEN MINDS."

          text="A global invitation to use science, technology, and creativity to understand our planet and explore what lies beyond."

        />

        <div className="info-split container section">

          <div className="emblem-visual">

            <img

              src="/img/event-emblem.jpeg"

              alt="NASA International Space Apps Challenge event emblem"

            />

          </div>

          <div>

            <Eyebrow>

              THE BIGGER MISSION

            </Eyebrow>

            <h2>

              REAL CHALLENGES.

              <br />

              YOUR PERSPECTIVE.

            </h2>

            <p>

              Space Apps brings together people

              with different skills to solve challenges

              using NASA and other open data. Coding

              is one route. Design, research,

              storytelling, and a thoughtful question

              can be just as important.

            </p>

            <p>

              ASTROVERSE is our local gathering in

              Bhimtal: a place to collaborate, explore

              space science, and make a meaningful

              prototype with your team.

            </p>

            <a

              className="button secondary"

                href="https://www.spaceappschallenge.org/"

              target="_blank"

              rel="noreferrer"

            >

              Explore NASA Space Apps

              <ArrowUpRight size={17} />

            </a>

          </div>

        </div>

        <HighlightsSection />

      </div>

    );

  }

  if (type === 'why-participate') {

    return (

      <div className="page">

        <PageIntro

          label="YOUR NEXT CHAPTER"

          title="COME CURIOUS. LEAVE CHANGED."

          text="You don’t have to know all the answers. You just have to be ready to explore them."

        />

        <div className="benefit-grid container section">

          {[

            [

              Lightbulb,

              'Ideas with purpose',

              'Apply creativity to real-world problems, from Earth’s environment to life in space.',

            ],

            [

              Code2,

              'Experience that stays with you',

              'Explore NASA data, develop technical skills, and add a meaningful project to your portfolio.',

            ],

            [

              Network,

              'A bigger circle',

              'Meet collaborators, exchange perspectives, and build your network.',

            ],

            [

              GraduationCap,

              'Learning by doing',

              'Find mentorship, join workshops, and discover tools you might never have tried.',

            ],

            [

              Mic2,

              'A platform for your ideas',

              'Present your project, tell its story, and practice explaining what makes it matter.',

            ],

            [

              Trophy,

              'The joy of building together',

              'Challenge yourself and create something as a team that you couldn’t have made alone.',

            ],

          ].map(

            ([Icon, title, text], index) => {

              const BenefitIcon =

                Icon as typeof Lightbulb;

              return (

                <article key={index}>

                  <BenefitIcon />

                  <span className="mono">

                    0{index + 1}

                  </span>

                  <h3>

                    {String(title)}

                  </h3>

                  <p>

                    {String(text)}

                  </p>

                </article>

              );

            }

          )}

        </div>

      </div>

    );

  }

  if (type === 'contact') {

    return (

      <div className="page">

        <PageIntro

          label="OUR LAUNCHPAD"

          title="SEE YOU IN BHIMTAL."

          text="Big ideas. Mountain air. A space to build something extraordinary."

        />

        <div className="contact-grid container section">

          <div>

            <Eyebrow>

              THE VENUE

            </Eyebrow>

            <h2>

              Birla Institute of

              <br />

              Applied Sciences

            </h2>

            <p>

              Bhimtal, Uttarakhand, India

            </p>

            <div className="contact-line">

              <CalendarDays />

              {event.dates}

            </div>

            <div className="contact-line">

              <MapPin />

              BIAS, Bhimtal

            </div>

            <a

              className="button secondary"

              href="https://www.google.com/maps/search/?api=1&query=Birla+Institute+of+Applied+Sciences+Bhimtal"

              target="_blank"

              rel="noreferrer"

            >

              Get directions

              <ArrowUpRight size={16} />

            </a>

            <p className="muted small">

              Organizer contact and social channels

              will be published here once confirmed.

              No unverified contact information is listed.

            </p>

          </div>

          <div className="contact-photo">

            <OptimizedImage

              src="/gallery/event-16.jpeg"

              alt="The event community gathered at the campus"

            />

            <span>

              YOUR IDEAS HAVE A HOME HERE.

            </span>

          </div>

        </div>

        <FAQSection preview />

      </div>

    );

  }

  if (type === 'media') {

    return (

      <div className="page">

        <PageIntro

          label="STORIES FROM THE LAUNCHPAD"

          title="BEHIND THE BIG IDEAS."

          text="The people, prototypes, and moments that make ASTROVERSE more than an event."

        />

        <div className="container section media-grid">

          {videos.length ? (

            videos.map((video) => (

              <article

                className="media-card"

                key={video.source}

              >

                {video.type === 'youtube' ? (

                  <iframe

                    src={`https://www.youtube-nocookie.com/embed/${video.source}`}

                    title={video.title}

                    loading="lazy"

                    allow="fullscreen; encrypted-media; picture-in-picture"

                    allowFullScreen

                  />

                ) : (

                  <video

                    src={video.source}

                    controls

                    preload="metadata"

                  />

                )}

                <h3>

                  {video.title}

                </h3>

              </article>

            ))

          ) : (

            <>

              <article className="media-story">

                <OptimizedImage

                  src="/gallery/event-19.jpeg"

                  alt="An event speaker sharing a science demonstration"

                />

                <div>

                  <span className="mono muted">

                    FROM THE EVENT ARCHIVE

                  </span>

                  <h3>

                    Every question starts a story.

                  </h3>

                  <p>

                    Ideas take the stage,

                    conversations spark,

                    and a new perspective begins.

                  </p>

                  <ArrowLink to="/gallery">

                    Discover the moments

                  </ArrowLink>

                </div>

              </article>

              <article className="media-story">

                <OptimizedImage

                  src="/gallery/event-17.jpeg"

                  alt="A real participant-built robotic prototype"

                />

                <div>

                  <span className="mono muted">

                    BUILDING WHAT COMES NEXT

                  </span>

                  <h3>

                    From open data to real prototypes.

                  </h3>

                  <p>

                    Official event films will be shared

                    when released. Until then, explore

                    the real event photo archive.

                  </p>

                  <ArrowLink to="/gallery">

                    Explore all 20 photos

                  </ArrowLink>

                </div>

              </article>

            </>

          )}

        </div>

      </div>

    );

  }

  return (

    <div className="page narrow">

      <Eyebrow>

        YOUR INFORMATION MATTERS

      </Eyebrow>

      <h1 className="page-title">

        PRIVACY & DECLARATION

      </h1>

      <div className="prose">

        <h2>

          Registration information

        </h2>

        <p>

          We collect team names, participant names,

          emails, mobile numbers, institutions, roles,

          optional ages, and optional mentor details

          to administer ASTROVERSE, review registrations,

          communicate event updates, and verify event access.

        </p>

        <h2>

          Access & verification

        </h2>

        <p>

          Your signed-in team members and authorized

          organizers can access team details. Public QR

          verification shows only the registration ID,

          team name, institution, size, status, and

          check-in state. It does not reveal participant

          emails or phone numbers.

        </p>

        <h2>

          Your declaration

        </h2>

        <p>

          By registering, you confirm that the information

          is accurate and that every member has agreed to

          share their details for event administration.

          For any member under 18, the team leader must

          confirm guardian consent. A submitted registration

          is pending until organizers approve it.

        </p>

        <h2>

          Corrections & deletion

        </h2>

        <p>

          Ask an authorized event organizer at Birla

          Institute of Applied Sciences for corrections,

          access, or deletion requests. Confirmed contact

          channels will be published on the contact page.

          Organizer exports are restricted to authenticated

          admin accounts.

        </p>

        <h2>

          Website storage

        </h2>

        <p>

          Authentication uses session storage and cookies

          provided by Netlify Identity. Registration records

          are stored in a managed PostgreSQL database.

          No payment information is collected by this site.

        </p>

      </div>

    </div>

  );

}

export function PageIntro({

  label,

  title,

  text,

}: {

  label: string;

  title: string;

  text: string;

}) {

  return (

    <div className="page-intro container">

      <Eyebrow>

        {label}

      </Eyebrow>

      <h1 className="page-title">

        {title}

      </h1>

      <p>

        {text}

      </p>

    </div>

  );

}
